{
  "extraPaths": ["."]
}